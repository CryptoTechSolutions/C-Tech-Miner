./miner --server  us.hushmine.pro --user t1VoR8JXjCPY2iSwFYdA8zVrrgKEvxeJEXH.createthis/YOUR_EMAIL --pec --fee 0 --pass z --port 9009
