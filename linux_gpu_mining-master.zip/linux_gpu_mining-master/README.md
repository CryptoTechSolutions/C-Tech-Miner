# Usage

## First time setup

```bash
./install_dependencies.sh # git, vim, and chrome
./enable_nvidia_fan_control.sh
./restart_ubuntu_lightdm.sh
```

## Every boot

```bash
./underclock.sh
./start.sh
```
